﻿namespace WeekPlanner
{
    public enum HeaderStyle
    {
        /// <summary>Aqua header's background style</summary>
        Aqua = 0,

        /// <summary>Simple header's background style</summary>
        Simple = 1
    }
}
